#plugin1

This is a simple example package.